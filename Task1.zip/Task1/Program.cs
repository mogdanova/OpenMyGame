﻿class Program
{
    static void Main(string[] args)
    {
        int a;
        Console.WriteLine("Enter the year");
        a = int.Parse(Console.ReadLine());
        {
            if ((a % 4) == 0)
                Console.WriteLine("It's a leap year.");
            else
                Console.WriteLine("It's not a leap year.");
        }
    }
}